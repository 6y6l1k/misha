﻿#include <iostream>

using namespace std;

//Вивести лише ті елементи масиву на друк, за якими слідує парний елемент.
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}
	for (int i = 0; i < n - 1; i++)
	{
		if (arr_ptr[i + 1] % 2 == 0)
		{
			cout << arr_ptr[i] << '\n';
		}
	}

	delete[] arr_ptr;

	return 0;
}