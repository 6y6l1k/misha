﻿#include <iostream>
#include <cmath>

using namespace std;

//Дано дійсний лінійний масив на N елементів. Обчислити суму модулів дробових частин елементів масиву А, значення яких за модулем більше 5.
int main()
{
	int n;
	cin >> n;

	double* arr_ptr = new double[n];
	double sum = 0.0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] < 0) arr_ptr[i] *= -1;
		if (arr_ptr[i] > 5)
		{
			int whole = (int) arr_ptr[i];
			double frac = arr_ptr[i] - whole;
			//cout << frac << '\n';

			sum += frac;
		}
	}

	cout << round(sum * 1000) / 1000;

	delete[] arr_ptr;

	return 0;
}