﻿#include <iostream>

using namespace std;

//У заданому лінійному масиві видалити лише останній від'ємний елемент. 
//Такий елемент у масиві обов'язково існує. Знайти суму індексів додатніх елементів перетвореного масиву.
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	int* arr_new_ptr = new int[n - 1];
	int last_minus_index = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] < 0) last_minus_index = i;
	}


	bool flag = false;
	for (int i = 0; i < n; i++)
	{
		if (i == last_minus_index)
		{
			flag = true;
			continue;
		}
		if (flag == true)
		{
			arr_new_ptr[i - 1] = arr_ptr[i];
			continue;
		}
		arr_new_ptr[i] = arr_ptr[i];
	}

	int index_summ = 0;
	for (int i = 0; i < n - 1; i++)
	{
		if (arr_new_ptr[i] > 0)
		{
			index_summ += i + 1;
		}
	}
	cout << index_summ << '\n';

	delete[] arr_ptr;
	delete[] arr_new_ptr;

	return 0;


}