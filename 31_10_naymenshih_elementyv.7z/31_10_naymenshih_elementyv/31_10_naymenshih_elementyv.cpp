﻿#include <iostream>

using namespace std;

void bubbleSort(int date[], int lenD);

int main()
{
	int n;
	cin >> n;
	
	int* arr_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}
	bubbleSort(arr_ptr, n);

	int sum = 0;
	for (int i = 0; i < 10; i++)
	{
		sum += arr_ptr[i];
	}
	cout << sum;

	delete[] arr_ptr;

	return 0;
}

void bubbleSort(int data[], int lenD)
{
	int tmp = 0;
	for (int i = 0; i < lenD; i++)
	{
		for (int j = (lenD - 1); j >= (i + 1); j--)
		{
			if (data[j] < data[j - 1])
			{
				tmp = data[j];
				data[j] = data[j - 1];
				data[j - 1] = tmp;
			}
		}
	}
}