﻿#include <iostream>

using namespace std;

bool checkIsPrime(int number);

int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}

	int sum = 0;
	for (int i = 0; i < n; i++)
	{
		if (checkIsPrime(arr_ptr[i]) == true)	sum += arr_ptr[i];
	}
	cout << sum;

	delete[] arr_ptr;

	return 0;
}

bool checkIsPrime(int number) {

	bool isPrimeNumber = true;
	// 0 и 1 не являются простыми числами 
	if (number == 0 || number == 1) isPrimeNumber = false;
	else
	{
		for (int i = 2; i <= number / 2; ++i)
		{
			if (number % i == 0)
			{
				isPrimeNumber = false;
				break;
			}
		}
	}

	return isPrimeNumber;
}