﻿#include <iostream>
#include <cmath>

using namespace std;

int factorial(int num);
double calculate_distance(int x1, int y1, int x2, int y2);

int main()
{
	int n;
	cin >> n;
	int a_len = 2 * n;
	
	int* arr_ptr = new int[a_len];
	for (int i = 0; i < a_len; i++)
	{
		cin >> arr_ptr[i];
	}

	//int results_len = factorial(n) / (factorial(2) * factorial(n - 2));
	//cout << results_len << '\n' << '\n';

	int p1 = -1, p2 = -1;
	double max_result = -1;
	for (int i = 0; i < a_len - 1; i+=2)
	{
		int x1_point = arr_ptr[i];
		int y1_point = arr_ptr[i + 1];
		for (int j = 0; j < a_len - 1; j+=2)
		{
			if (i <= j) continue;
			int x2_point = arr_ptr[j];
			int y2_point = arr_ptr[j + 1];

			double dist = calculate_distance(x1_point, y1_point, x2_point, y2_point);
			//cout << dist << '\n';
			if (max_result < dist)
			{
				max_result = dist; 
				p1 = i;
				p2 = j;
			}
		}
	}
	//cout << "\n\n" << max_result << '\n';
	p1 = p1 / 2 + 1;
	p2 = p2 / 2 + 1;
	if (p1 > p2) cout << p2 << ' ' << p1;
	else cout << p1 << ' ' << p2;
	
	delete[] arr_ptr;

	return 0;
}

int factorial(int num)
{
	int result = num;
	for (int i = num - 1; i > 0; i--)
	{
		result *= i;
	}
	return result;
}

double calculate_distance(int x1, int y1, int x2, int y2)
{
	return (sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2)));
}
