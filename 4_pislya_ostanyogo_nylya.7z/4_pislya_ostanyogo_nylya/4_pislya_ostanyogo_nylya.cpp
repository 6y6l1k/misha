﻿#include <iostream>

using namespace std;

//Після останнього нуля
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	int last_zero_index = -1;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] == 0) last_zero_index = i;
	}
	if (last_zero_index == -1)
	{
		for (int i = 0; i < n; i++)
		{
			cout << arr_ptr[i] << ' ';
		}
	}
	else
	{
		for (int i = last_zero_index + 1; i < n; i++)
		{
			cout << arr_ptr[i] << ' ';
		}
	}

	delete[] arr_ptr;

	return 0;
}