﻿#include <iostream>

using namespace std;

bool checkIsPrime(int number);

//Знайти кількість тих елементів числової послідовності, значення яких є простими числами.
int main()
{
    int n;
    cin >> n;

    int* arr_ptr = new int[n];
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> arr_ptr[i];
        if (checkIsPrime(arr_ptr[i]) == true) count += 1;
    }

    cout << count;

    delete[] arr_ptr;

    return 0;
}

bool checkIsPrime(int number) {

    bool isPrimeNumber = true;
    // 0 и 1 не являются простыми числами 
    if (number == 0 || number == 1) 
    {
        isPrimeNumber = false;
    }
    else 
    {
        for (int i = 2; i <= number / 2; ++i) 
        {
            if (number % i == 0) 
            {
                isPrimeNumber = false;
                break;
            }
        }
    }

    return isPrimeNumber;
}