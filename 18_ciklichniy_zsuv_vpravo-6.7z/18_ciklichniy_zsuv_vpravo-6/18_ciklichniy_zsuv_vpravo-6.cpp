﻿#include <iostream>

using namespace std;

//Дано лінійний масив на N елементів. 
//Виконати циклічний зсув всіх його елементів вправо доти, доки нульовий елемент не з'явиться на останньому місці. Нульовий елемент обов'язково існує.
int main()
{
	int n, k = 0;
	cin >> n;

	int* arr_ptr = new int[n];
	int* arr_copy_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		int number;
		cin >> number;
		arr_ptr[i] = number;
		arr_copy_ptr[i] = number;
	}

	while (arr_ptr[n - 1] != 0)
	{
		for (int i = k; i < n; i++) //1-4
		{
			arr_ptr[i] = arr_copy_ptr[i - 1];
		}
		arr_ptr[k] = arr_copy_ptr[n - 1];
		for (int i = 0; i < n; i++)
		{
			arr_copy_ptr[i] = arr_ptr[i];
		}
	}
	for (int i = 0; i < n; i++)
	{
		cout << arr_ptr[i] << ' ';
	}

	delete[] arr_ptr;
	delete[] arr_copy_ptr;

	return 0;
}