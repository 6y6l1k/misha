﻿#include <iostream>

using namespace std;

bool checkIsPrime(int number);

// Видалити всі прості елементи заданого натурального масиву, 
//а в перетвореному масиві визначити кількість мінімальних елементів. Якщо будуть видалені всі елементи масиву, вивести NO.
int main()
{
    int n;
    cin >> n;

    int* arr_ptr = new int[n];
    int prime_counter = 0;
    for (int i = 0; i < n; i++) 
    {
        cin >> arr_ptr[i];

        if (checkIsPrime(arr_ptr[i]) == true) prime_counter++;
    }

    int new_len = n - prime_counter;
    if (new_len == 0)
    {
        cout << "NO";
        return 0;
    }

    int* arr_new_ptr = new int[new_len];
    int counter = 0;
    for (int i = 0; i < n; i++)
    {
        if (checkIsPrime(arr_ptr[i]) == true)
        {
            ++counter;
            continue;
        }
        arr_new_ptr[i - counter] = arr_ptr[i];
    }

    int minimum = arr_new_ptr[0];
    int minimum_counter = 0;
    for (int i = 0; i < new_len; i++)
    {
        if (arr_new_ptr[i] < minimum)
        {
            minimum = arr_new_ptr[i];
            minimum_counter = 1;
            continue;
        }
        if (arr_new_ptr[i] == minimum)
        {
            minimum_counter++;
        }   
    }
    cout << minimum << ' ' << minimum_counter;

    delete[] arr_ptr;
    delete[] arr_new_ptr;

    return 0;
}

bool checkIsPrime(int number)
{
    if (number > 1)
    {
        for (int i = 2; i < number; i++)
        {
            if (number % i == 0) return false;
        }
        return true;
    }
    else return false;
}