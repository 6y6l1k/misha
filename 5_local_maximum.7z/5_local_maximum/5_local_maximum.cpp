﻿#include <iostream>

using namespace std;

//Вивести всі локальні максимуми заданої числової послідовності у прямому порядку.
int main()
{
    int n;
    cin >> n;

    int* arr_ptr = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr_ptr[i];
    }

    int i = 1;
    while (i <= (n - 2)) {
        if (arr_ptr[i] > arr_ptr[i - 1] && arr_ptr[i] > arr_ptr[i + 1]) {
            cout << arr_ptr[i] << ' ';
        }
        i++;
    }

    delete[] arr_ptr;

    return 0;
}

