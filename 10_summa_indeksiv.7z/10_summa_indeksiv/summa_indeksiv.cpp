﻿#include <iostream>

using namespace std;

//Дано дійсний лінійний масив на N елементів.Знайти суму індексів від'ємних елементів масиву.
int main()
{
	int n;
	cin >> n;

	double* arr_ptr = new double[n];
	int sum = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] < 0)
		{
			sum += i + 1;
		}
	}

	cout << sum;

	delete[] arr_ptr;

	return 0;
}