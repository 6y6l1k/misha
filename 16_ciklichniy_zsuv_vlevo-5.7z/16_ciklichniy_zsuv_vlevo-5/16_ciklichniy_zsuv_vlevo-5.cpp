﻿#include <iostream>

using namespace std;

//Даний лінійний масив N елементів. 
//Виконати циклічний зсув всіх його елементів на один ліворуч, 
//починаючи з останнього нульового елемента. Нульовий елемент обов'язково існує.
int main()
{
	int n, k = 0;
	cin >> n;

	int* arr_ptr = new int[n];
	int* arr_copy_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		int number;
		cin >> number;
		arr_ptr[i] = number;
		arr_copy_ptr[i] = number;

		if (arr_ptr[i] == 0) k = i;
	}

	for (int i = k; i < n - 1; i++)
	{
		arr_ptr[i] = arr_copy_ptr[i + 1];
	}
	arr_ptr[n - 1] = arr_copy_ptr[k];

	for (int i = 0; i < n; i++)
	{
		cout << arr_ptr[i] << ' ';
	}

	delete[] arr_ptr;
	delete[] arr_copy_ptr;

	return 0;
}