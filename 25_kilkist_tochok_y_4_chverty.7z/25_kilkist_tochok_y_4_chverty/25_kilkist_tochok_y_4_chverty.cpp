﻿#include <iostream>
#include <cmath>

using namespace std;

double calculate(int index, int number);

//Лінійний масив A містить 2*N елементів, значення яких задаються за формулою a[i]:=10*sin(N+i*i). Елементи масиву нумеруються з одиниці.
//Вважаючи значення елементів А[1] і А[2] - координатами першої точки, елементи А[3] та А[4] - другої точки і т. д., обчислити кількість 
//точок розташованих у четвертій чверті площині.
int main()
{
	int N;
	cin >> N;
	int A_len = 2 * N;
	double* A_ptr = new double[A_len];
	int count = 0;

	for (int i = 0; i < A_len; i++)
	{
		A_ptr[i] = calculate(i, N);
	}

	for (int i = 0; i < A_len - 1; i += 2)
	{
		double x_point = A_ptr[i];
		double y_point = A_ptr[i + 1];

		if (x_point > 0 && y_point < 0)
		{
			count++;
		}
	}
	cout << count;

	delete[] A_ptr;

	return 0;
}

double calculate(int index, int number)
{
	return (10 * sin(number + index * index));
}