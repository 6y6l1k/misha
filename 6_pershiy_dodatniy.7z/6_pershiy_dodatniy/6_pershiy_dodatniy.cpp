﻿#include <iostream>

using namespace std;

//Вивести значення першого додатнього елемента числової послідовності. Відомо, що такий елемент є.
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}
	for (int i = 0; i < n; i++)
	{
		if (arr_ptr[i] > 0)
		{
			cout << arr_ptr[i];
			break;
		}
	}

	delete[] arr_ptr;

	return 0;
}