﻿#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

double calculate_distance_to_center(double x_point, double y_point);
void bubbleSort(double data[], int lenD);

int main()
{
	int n;
	cin >> n;
	int A_len = 2 * n;

	int* arr_ptr = new int[A_len];
	for (int i = 0; i < A_len; i++)
	{
		cin >> arr_ptr[i];
	}

	double* results = new double[n];
	int index = 0;
	for (int i = 0; i < A_len - 1; i += 2)
	{
		int x_point = arr_ptr[i];
		int y_point = arr_ptr[i + 1];

		results[index] = calculate_distance_to_center((double)x_point, (double)y_point);
		index++;
	}

	bubbleSort(results, n);
	for (int i = 0; i < n; i++)
	{
		cout << fixed << setprecision(3) << round(results[i] * 1000) / 1000 << '\n';
	}

	delete[] arr_ptr;
	delete[] results;

	return 0;
}

double calculate_distance_to_center(double x_point, double y_point)
{
	return (sqrt(pow(x_point, 2) + pow(y_point, 2)));
}

void bubbleSort(double data[], int lenD)
{
	double tmp = 0;
	for (int i = 0; i < lenD; i++) 
	{
		for (int j = (lenD - 1); j >= (i + 1); j--) 
		{
			if (data[j] > data[j - 1]) 
			{
				tmp = data[j];
				data[j] = data[j - 1];
				data[j - 1] = tmp;
			}
		}
	}
}