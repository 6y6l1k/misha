﻿#include <iostream>
#include <cmath>

using namespace std;

double calculate_value(int index, int number);
double calculate_distance_to_center(double x_point, double y_point);

int main()
{
	int n = 86;
	//cin >> n;
	double r = 3.628;
	//cin >> r;

	int A_len = 2 * n;
	double* A_ptr = new double[A_len];
	for (int i = 0; i < A_len; i++)
	{
		A_ptr[i] = calculate_value(i, n);
	}

	int count = 0;
	for (int i = 0; i < A_len - 1; i += 2)
	{
		double x_point = A_ptr[i];
		double y_point = A_ptr[i + 1];

		if (x_point >= 0 && y_point <= 0 && r >= calculate_distance_to_center(x_point, y_point))
		{
			count++;
		}
	}
	//cout << "count = " << count << '\n';

	double* distances = new double[count];
	int index = 0;
	for (int i = 0; i < A_len - 1; i += 2)
	{
		double x_point = A_ptr[i];
		double y_point = A_ptr[i + 1];

		if (x_point >= 0 && y_point <= 0 && r >= calculate_distance_to_center(x_point, y_point))
		{
			distances[index] = calculate_distance_to_center(x_point, y_point);
			//cout << "x: " << x_point << "\ty: " << y_point<< "\tdistance: " << distances[index] << '\n';
			index++;
		}
	}
	//cout << "index = " << index << '\n';

	double minimum = distances[0];
	for (int i = 1; i < count; i++)
	{
		if (minimum > distances[i]) minimum = distances[i];
	}
	cout << round(minimum * 1000) / 1000;

	delete[] A_ptr;
	delete[] distances;

	return 0;
}

double calculate_value(int index, int number)
{
	index += 1;
	return (10 * sin(number + index * index));
}

double calculate_distance_to_center(double x_point, double y_point)
{
	return (sqrt(pow(x_point, 2) + pow(y_point, 2)));
}
