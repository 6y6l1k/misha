﻿#include <iostream>
#include <cmath>

using namespace std;

//Дано дійсний лінійний масив на N елементів. Обчислити кількість елементів масиву А, в яких модуль дробової частини перевищує 0.5.

int main()
{
	int n;
	cin >> n;

	double* arr_ptr = new double[n];
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] < 0) arr_ptr[i] *= -1;

		int whole = (int)arr_ptr[i];
		double frac = arr_ptr[i] - whole;
		if (frac > 0.5) count += 1;
	}

	cout << count;

	delete[] arr_ptr;

	return 0;
}