﻿#include <iostream>

using namespace std;

//Даний лінійний масив N елементів. 
//Виконати циклічний зсув всіх його елементів на один ліворуч, 
//починаючи з k-го елемента. (Елемент з індексом k у такому разі переміщається 
//до кінця масиву). Індексація елементів масиву починається з одиниці.
int main()
{
	int n, k;
	cin >> n;
	cin >> k;

	int* arr_ptr = new int[n];
	int* arr_copy_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		int number;
		cin >> number;
		arr_ptr[i] = number;
		arr_copy_ptr[i] = number;
	}

	for (int i = k - 1; i < n - 1; i++)
	{
		arr_ptr[i] = arr_copy_ptr[i + 1];
	}
	arr_ptr[n - 1] = arr_copy_ptr[k - 1];

	for (int i = 0; i < n; i++)
	{
		cout << arr_ptr[i] << ' ';
	}

	delete[] arr_ptr; 
	delete[] arr_copy_ptr;

	return 0;
}