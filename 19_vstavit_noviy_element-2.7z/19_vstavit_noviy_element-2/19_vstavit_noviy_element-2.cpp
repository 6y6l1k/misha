﻿#include <iostream>

using namespace std;

//У заданому лінійному масиві вставити перед першим додатнім елементом елемент, 
//значення якого дорівнює значенню останнього елемента масиву. Додатній елемент обов'язково існує.
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	int* arr_new_ptr = new int[n + 1];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}

	bool flag = false;
	for (int i = 0; i < n; i++) 
	{
		if (arr_ptr[i] >= 0 && flag == false)
		{
			flag = true;
			arr_new_ptr[i] = arr_ptr[n - 1];
			arr_new_ptr[i + 1] = arr_ptr[i];
			continue;
		}
		if (flag == false)
		{
			arr_new_ptr[i] = arr_ptr[i];
			continue;
		}
		arr_new_ptr[i + 1] = arr_ptr[i];
	}

	for (int i = 0; i < n + 1; i++)
	{
		cout << arr_new_ptr[i] << ' ';
	}

	delete[] arr_ptr;
	delete[] arr_new_ptr;

	return 0;
}