﻿#include <iostream>

using namespace std;

void bubbleSort(int data[], int lenD);

int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
	}
	
	int start_index = 0, end_index = n - 1;
	bool start_writed = false;
	for (int i = 0; i < n; i++)
	{
		if (start_writed == false && arr_ptr[i] > 0)
		{
			start_index = i;
			start_writed = true;
			
		}
		else if (start_writed == true && arr_ptr[i] > 0)
		{
			end_index = i;
		}
	}
	//cout << start_index << ' ' << end_index << '\n';

	int new_len = end_index - start_index + 1;
	//cout << "new_len = " << new_len << '\n';
	int* arr2_ptr = new int[new_len];
	int index = 0;
	//cout << "srez massiv = ";
	for (int i = start_index; i <= end_index; i++)
	{
		arr2_ptr[index] = arr_ptr[i];
		cout << arr2_ptr[index] << ' ';
		index++;
	}
	bubbleSort(arr2_ptr, new_len);

	index = 0;
	for (int i = start_index; i <= end_index; i++)
	{
		arr_ptr[i] = arr2_ptr[index];
		index++;
	}

	//cout << '\n';
	for (int i = 0; i < n; i++)
	{
		cout << arr_ptr[i] << ' ';
	}

	delete[] arr_ptr;
	delete[] arr2_ptr;

	return 0;
}

void bubbleSort(int data[], int lenD)
{
	int tmp = 0;
	for (int i = 0; i < lenD; i++)
	{
		for (int j = (lenD - 1); j >= (i + 1); j--)
		{
			if (data[j] < data[j - 1])
			{
				tmp = data[j];
				data[j] = data[j - 1];
				data[j - 1] = tmp;
			}
		}
	}
}