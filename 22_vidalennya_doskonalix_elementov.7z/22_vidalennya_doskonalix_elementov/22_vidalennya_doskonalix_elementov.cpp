﻿#include <iostream>

using namespace std;

bool checkIsPerfect(int number);
bool checkIsPrime(int number);

//Дано цілочисловий лінійний масив на N елементів. Видалити з масиву елементи, значення яких є досконалими числами. 
//У перетвореному масиві знайти суму індексів простих елементів.

//Досконале число (др.-грец. ἀριθμὸς τέλειος) - натуральне число, що дорівнює сумі всіх своїх власних дільників 
//(тобто всіх додатніх дільників, відмінних від самого числа). У міру того, як натуральні числа зростають, досконалі числа зустрічаються все рідше.
int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	int perfect_counter = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];

		if (checkIsPerfect(arr_ptr[i]) == true) perfect_counter++;
	}

	int new_len = n - perfect_counter;
	int* arr_new_ptr = new int[new_len];
	int counter = 0;
	//int sum = 0;
	for (int i = 0; i < n; i++)
	{
		if (checkIsPerfect(arr_ptr[i]) == true)
		{
			++counter;
			continue;
		}
		arr_new_ptr[i - counter] = arr_ptr[i];
	}

	//У перетвореному масиві знайти суму індексів простих елементів.
	counter = 0;
	for (int i = 0; i < new_len; i++)
	{
		if (checkIsPrime(arr_new_ptr[i]) == true)
		{
			counter += i + 1;
		}
	}
	cout << counter;

	delete[] arr_ptr;
	delete[] arr_new_ptr;
	
	return 0;
}

bool checkIsPerfect(int number)
{
	int sum = 0;
	for (int i = 1; i < number; i++)
	{
		if (number % i == 0) sum += i;
	}

	if (sum == number) return true;
	else return false;
}

bool checkIsPrime(int number)
{
	if (number > 1)
	{
		for (int i = 2; i < number; i++)
		{
			if (number % i == 0) return false;
		}
		return true;
	}
	else return false;
}