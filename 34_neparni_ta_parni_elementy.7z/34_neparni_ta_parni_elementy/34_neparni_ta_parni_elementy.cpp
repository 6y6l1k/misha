﻿#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;

	int* arr_ptr = new int[n];
	int nepar_count = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> arr_ptr[i];
		if (arr_ptr[i] % 2 != 0) nepar_count++;
	}

	int* nepar_element = new int[nepar_count];
	int* par_element = new int[n - nepar_count];
	int index_1 = 0, index_2 = 0;

	for (int i = 0; i < n; i++)
	{
		if (arr_ptr[i] % 2 == 0)
		{
			par_element[index_1] = arr_ptr[i];
			index_1++;
		}
		else
		{
			nepar_element[index_2] = arr_ptr[i];
			index_2++;
		}
	}

	for (int i = 0; i < index_2; i++)
	{
		cout << nepar_element[i] << ' ';
	}
	for (int i = 0; i < index_1; i++)
	{
		cout << par_element[i] << ' ';
	}

	delete[] arr_ptr;
	delete[] nepar_element;
	delete[] par_element;

	return 0;
}